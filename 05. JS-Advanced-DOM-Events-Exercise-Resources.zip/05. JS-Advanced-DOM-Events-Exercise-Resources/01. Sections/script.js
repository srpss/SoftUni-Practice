function create(words) {
   for (let i = 0; i < words.length; i++) {
      let theDiv = document.createElement("div");
      let theP =document.createElement("P");
      let theText =document.createTextNode(words[i]);
      theP.appendChild(theText);
      theP.style.display = "none"
      theDiv.appendChild(theP);
      theDiv.addEventListener('click', test123);
      theDiv.id = "content";
      document.querySelector("div").appendChild(theDiv);  

      function test123(){
         if (theDiv.firstChild.style.display === "none") {
            theDiv.firstChild.style.display = "block";
         } else{
            theDiv.firstChild.style.display = "none";
         }   
      }
  
} 
  
}

