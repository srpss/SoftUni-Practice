function addItem() {
    let text = document.querySelector("#newItemText").value;
    let valuer = document.querySelector("#newItemValue").value;
    let theOption = document.createElement("option");
    theOption.innerHTML = text;
    theOption.value = valuer;
    document.querySelector("#menu").appendChild(theOption);
    text.innerHTML = "";
    valuer.innerHTML ="";
}