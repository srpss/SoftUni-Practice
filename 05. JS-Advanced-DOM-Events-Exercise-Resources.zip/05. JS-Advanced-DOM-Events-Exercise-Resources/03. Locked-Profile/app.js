function lockedProfile() {
    let buttons = document.querySelectorAll(".profile button");
    for (let i = 0; i < buttons.length; i++) {
        if (i == 0) {
            buttons[i].addEventListener('click', hide0)
        }
        else if (i == 1) {
            buttons[i].addEventListener('click', hide1)
        }
        
        else if (i == 2) {
            buttons[i].addEventListener('click', hide2)
        }
        
    }
    function hide0(){
        
        let checker = document.querySelectorAll('input[name="user1Locked"]')
        if (!(checker[0].checked)) {
            let buttons = document.querySelectorAll(".profile button");
            if (buttons[0].innerHTML == "Show more") {               
                buttons[0].innerHTML = "Hide it";
                let info = document.querySelector("#user1HiddenFields");
                info.style.display = 'block';
            }
            else if (buttons[0].innerHTML == "Hide it") {
                buttons[0].innerHTML = "Show more";
                let info = document.querySelector("#user1HiddenFields");
                info.style.display = 'none';
            }
        }
    }
    function hide1(){
        
        let checker = document.querySelectorAll('input[name="user2Locked"]')
        if (!(checker[0].checked)) {
            let buttons = document.querySelectorAll(".profile button");
            if (buttons[1].innerHTML == "Show more") {               
                buttons[1].innerHTML = "Hide it";
                let info = document.querySelector("#user2HiddenFields");
                info.style.display = 'block';
            }
            else if (buttons[1].innerHTML == "Hide it") {
                buttons[1].innerHTML = "Show more";
                let info = document.querySelector("#user2HiddenFields");
                info.style.display = 'none';
            }
        }
    }
    function hide2(){
        let checker = document.querySelectorAll('input[name="user3Locked"]')
        if (!(checker[0].checked)) {
            let buttons = document.querySelectorAll(".profile button");
            if (buttons[2].innerHTML == "Show more") {               
                buttons[2].innerHTML = "Hide it";
                let info = document.querySelector("#user3HiddenFields");
                info.style.display = 'block';
            }
            else if (buttons[2].innerHTML == "Hide it") {
                buttons[2].innerHTML = "Show more";
                let info = document.querySelector("#user3HiddenFields");
                info.style.display = 'none';
            }
        }
    }
}
