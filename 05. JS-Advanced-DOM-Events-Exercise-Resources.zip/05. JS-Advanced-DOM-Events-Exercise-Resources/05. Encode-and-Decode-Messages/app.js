function encodeAndDecodeMessages() {
    
}