function attachEventsListeners() {

    document.querySelector("#daysBtn").addEventListener('click', dayConvert);  
    document.querySelector("#hoursBtn").addEventListener('click', hourConvert);
    document.querySelector("#minutesBtn").addEventListener('click', minConvert);
    document.querySelector("#secondsBtn").addEventListener('click', secConvert);

    function dayConvert(){
        let currentValue = document.querySelector("#days").value;
        document.querySelector("#hours").value = currentValue * 24;
        document.querySelector("#minutes").value = 24 * 60 * currentValue;
        document.querySelector("#seconds").value = 24 * 60 * 60 * currentValue;
    }
    function hourConvert(){
        let currentValue = document.querySelector("#hours").value;
        document.querySelector("#days").value = currentValue / 24;
        document.querySelector("#minutes").value = 60 * currentValue;
        document.querySelector("#seconds").value = 60 * 60 * currentValue;
    }
    function minConvert(){
        let currentValue = document.querySelector("#minutes").value;
        document.querySelector("#days").value =  (currentValue / 60) /24;
        document.querySelector("#hours").value = currentValue /60;  
        document.querySelector("#seconds").value = 60 * currentValue;
    }
    function secConvert(){
        let currentValue = document.querySelector("#seconds").value;
        document.querySelector("#days").value = (( currentValue /60 ) / 60)/ 24;
        document.querySelector("#hours").value = (currentValue / 60) / 60;
        document.querySelector("#minutes").value =  currentValue / 60 ;
        
    }
}
