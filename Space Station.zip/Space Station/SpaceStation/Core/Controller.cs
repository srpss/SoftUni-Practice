﻿using SpaceStation.Core.Contracts;
using SpaceStation.Models.Astronauts;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Mission;
using SpaceStation.Models.Planets;
using SpaceStation.Models.Planets.Contracts;
using SpaceStation.Repositories;
using SpaceStation.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceStation.Core
{
    class Controller : IController
    {
        private AstronautRepository astRepo;
        private PlanetRepository planetRepo;
        private List<IPlanet> exploredPlanetsCount;
        public Controller()
        {
            astRepo = new AstronautRepository();
            planetRepo = new PlanetRepository();
            exploredPlanetsCount = new List<IPlanet>();
        }
        public string AddAstronaut(string type, string astronautName)
        {
            if (type != "Biologist" && type != "Geodesist" && type != "Meteorologist" )
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidAstronautType);
            }
            IAstronaut astronaut = null;
            if (type == "Biologist")
            {
                astronaut = new Biologist(astronautName);
            }
            else if (type == "Geodesist")
            {
                astronaut = new Geodesist(astronautName);
            }
            else if (type == "Meteorologist")
            {
                astronaut = new Meteorologist(astronautName);
            }
            astRepo.Add(astronaut);
            return $"Successfully added {type}: {astronautName}!";
        }

        public string AddPlanet(string planetName, params string[] items)
        {
            Planet planet = new Planet(planetName);
            foreach (var item in items)
            {
                planet.Items.Add(item);
            }            
            planetRepo.Add(planet);
            return $"Successfully added Planet: {planetName}!";
        }
        public string RetireAstronaut(string astronautName)
        {
            if (!astRepo.GetType().Name.Contains(astronautName))
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InvalidRetiredAstronaut, astronautName));
            }
            IAstronaut test = new Biologist(astronautName);
            astRepo.Remove(test);
            return $"Astronaut {astronautName} was retired!";
        }
        public string ExplorePlanet(string planetName)
        {
            Mission mission = new Mission();
            IPlanet planet = planetRepo.FindByName(planetName);
            List<IAstronaut> astList = new List<IAstronaut>();
            foreach (var item in astRepo.Models)
            {
                if (item.Oxygen > 60)
                {
                    astList.Add(item);
                }
            }
            if (astList.Count == 0)
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidAstronautCount);
            }
            mission.Explore(planet, astList);
            if (!exploredPlanetsCount.GetType().Name.Contains(planet.Name))
            {
                exploredPlanetsCount.Add(planet);
            }
            int deadAst = astList.Where(n => n.Oxygen == 0).Count();
            return $"Planet: {planetName} was explored! Exploration finished with {deadAst} dead astronauts!";
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{exploredPlanetsCount.Count} planets were explored!");
            sb.AppendLine("Astronauts info:");
            foreach (var item in astRepo.Models)
            {
                sb.AppendLine($"Name: {item.Name}");
                sb.AppendLine($"Oxygen: {item.Oxygen}");
                if (item.Bag.Items.Count == 0)
                {
                    sb.AppendLine($"Bag items: none");
                }
                else
                {
                    sb.AppendLine($"Bag items: {string.Join(", ", item.Bag.Items)}");
                }              
            }
            return sb.ToString().TrimEnd();
        }       
    }
}
