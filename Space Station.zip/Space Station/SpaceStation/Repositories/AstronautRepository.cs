﻿using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace SpaceStation.Repositories
{
    class AstronautRepository : IRepository<IAstronaut>
    {
        private readonly List<IAstronaut> models;

        public AstronautRepository()
        {
            this.models = new List<IAstronaut>();
        }

        public IReadOnlyCollection<IAstronaut> Models => this.models.AsReadOnly();

        public void Add(IAstronaut model)
        {
            bool exists = false;
            foreach (var item in this.models)
            {
                if(item.Name == model.Name)
                {
                    exists = true;
                    break;
                }
            }
            if (exists == false)
            {
                this.models.Add(model);
                
            }           
        }
        public bool Remove(IAstronaut model)
        {
            int index = 0;
            bool found = false;
            foreach (var item in models)
            {
                if (item.Name == model.Name)
                {
                    found = true;
                }
                index++;
            }
            if (found == false)
            {
                return false;
            }
            else
            {
                models.RemoveAt(index);
                return true;
            }
            
        }
        public IAstronaut FindByName(string name)
        {
            //return models.FirstOrDefault(x => x.GetType().Name == name);
            foreach (var item in models)
            {
                if (item.Name == name)
                {
                    return item;
                }
            }
            return null;
        }

       
    }
}
