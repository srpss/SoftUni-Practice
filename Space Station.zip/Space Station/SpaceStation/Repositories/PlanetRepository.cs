﻿using SpaceStation.Models.Planets.Contracts;
using SpaceStation.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceStation.Repositories
{
    class PlanetRepository : IRepository<IPlanet>
    {
        private readonly List<IPlanet> models;

        public PlanetRepository()
        {
            this.models = new List<IPlanet>();
        }

        public IReadOnlyCollection<IPlanet> Models => throw new NotImplementedException();

        public void Add(IPlanet model)
        {
            bool exists = false;
            foreach (var item in models)
            {
                if (item.Name == model.Name)
                {
                    exists = true;
                    break;
                }
            }
            if (exists == false)
            {
                models.Add(model);
            }
        }
        public bool Remove(IPlanet model)
        {
            int index = 0;
            bool found = false;
            foreach (var item in models)
            {
                if (item.Name == model.Name)
                {
                    found = true;
                }
                index++;
            }
            if (found == false)
            {
                return false;
            }
            else
            {
                models.RemoveAt(index);
                return true;
            }

        }
        public IPlanet FindByName(string name)
        {
            foreach (var item in models)
            {
                if (item.Name == name)
                {
                    return item;
                }
            }
            return null;
        }
    }
}
