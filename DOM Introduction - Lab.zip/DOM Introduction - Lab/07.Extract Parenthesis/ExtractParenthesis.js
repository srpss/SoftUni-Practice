function extract(content) {
let text = document.querySelector(`#${content}`).innerHTML
const regexp = new RegExp(/\((.*?)\)/,'g');
const matched = text.match(regexp);
let stringed = "";
for (let i = 0; i < matched.length; i++) {
    let el = matched[i];
    el = el.slice(1, el.length-1)
    stringed += el + "; "
    
}
let final = stringed.slice(0, stringed.length - 2 )
return final;
}