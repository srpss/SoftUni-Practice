function extractText() {
    let values = document.querySelectorAll("li")
    for (let i = 0; i < values.length; i++) {
        document.querySelector("#result").innerHTML += values[i].innerHTML
        document.querySelector("#result").innerHTML += "\n"
    }
}