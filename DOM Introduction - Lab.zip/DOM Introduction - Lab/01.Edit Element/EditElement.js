function editElement(ref, page, result) {

        const content = ref.textContent;
        
        const matcher = new RegExp(page, 'g');
        
        const edited = content.replace(matcher, result);
        
        ref.textContent = edited;      
}