function sumTable() {
let el = document.querySelectorAll("table tr");;
let total = 0;
for (let i = 1; i < el.length; i++) {
    
        total += Number(el[i].lastChild.innerText) 
    
    
}
document.querySelector("#sum").innerText = total;
}