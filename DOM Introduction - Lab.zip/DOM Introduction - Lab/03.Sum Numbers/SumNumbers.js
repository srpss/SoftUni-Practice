function calc() {
    document.querySelector("#sum").value =   Number (document.querySelector("#num1").value) + Number (document.querySelector("#num2").value);
}
