function colorize() {
    let el = document.querySelectorAll("tr");
    for (let i = 1; i < el.length; i++) {
        if (i % 2 == 1) {
            el[i].style.background ="Teal"
        }
        
    }
}