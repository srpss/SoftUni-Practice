function showText() {
   elem = document.querySelector("a")
   elem.style.display = "none"
   elem1 = document.querySelector("#text")
   elem1.style.display = "inline"
}