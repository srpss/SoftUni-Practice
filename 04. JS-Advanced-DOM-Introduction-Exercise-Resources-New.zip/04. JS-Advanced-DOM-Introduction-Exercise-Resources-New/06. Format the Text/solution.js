function solve() {
  let text = document.querySelector("#input").value;
  let arrText = text.split(".")
  

  
  let counter = 0;
  let current = [];
  for (let i = 0; i < arrText.length; i++) {
    if (arrText[i].length < 1) {
      continue;
    }
    current.push(arrText[i].trim());
    counter++;
    if(counter == 3){
      let b = document.createElement("P");
    let theText =current.join(". ") + "."
      let t = document.createTextNode(theText);
      b.appendChild(t);
      document.querySelector("#output").appendChild(b);
      counter = 0;
      current = [];
    }
  
  
  }
  if (counter > 0 ) {
    let b = document.createElement("P");
    let theText =current.join(". ") + "."
      let t = document.createTextNode(theText);
      b.appendChild(t);
      document.querySelector("#output").appendChild(b);
      counter = 0;
      current = [];
  }
  
}