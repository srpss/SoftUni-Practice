function solve() {
  let cases = document.querySelector("#naming-convention").value;
  let text = document.querySelector("#text").value;
  let result = "";
  let arrText = text.split(" ");
  if (cases == "Camel Case") {      
      for (let i = 0; i < arrText.length; i++) {
        if (i == 0) {
          let first = arrText[i];
          let letter = first[0].toLowerCase() + first.slice(1, first.length).toLowerCase();
          result += letter;
          continue;
        }
        let first = arrText[i];
        let letter = first[0].toUpperCase() + first.slice(1, first.length).toLowerCase();
        result += letter;
      }
      document.querySelector("#result").innerHTML = result;
  }else if(cases == "Pascal Case"){
    for (let i = 0; i < arrText.length; i++) {   
      let first = arrText[i];
      let letter = first[0].toUpperCase() + first.slice(1, first.length).toLowerCase();
      result += letter;
    }
    document.querySelector("#result").innerHTML = result;
  }else{
      document.querySelector("#result").innerHTML = "Error!";
  }
  
}
