function search() {

 let textArr = document.querySelectorAll("#towns li");
 for (let i = 0; i < textArr.length; i++) {
   textArr[i].style.fontWeight = 'normal'
   textArr[i].style.textDecoration = "none";
 }
 let searcher = document.querySelector("#searchText").value.toLowerCase();
 let matcher = new RegExp(`${searcher}`, "g")
 let counter = 0;
 for (let i = 0; i < textArr.length; i++) {
    if (textArr[i].innerHTML.toLowerCase().match(matcher)){
       textArr[i].style.fontWeight = 'bold'
       textArr[i].style.textDecoration = "underline";
       counter++;
    }
    document.querySelector("#result").innerHTML = counter;
}
}
 
