function toggle() {
    let check = document.querySelector(".button").innerHTML
    if (check == "More") {
        document.querySelector(".button").innerHTML = "Less";
        document.querySelector("#extra").style.display = "block";
    }else if(check == "Less"){
        document.querySelector(".button").innerHTML = "More";
        document.querySelector("#extra").style.display = "none";
    }
}