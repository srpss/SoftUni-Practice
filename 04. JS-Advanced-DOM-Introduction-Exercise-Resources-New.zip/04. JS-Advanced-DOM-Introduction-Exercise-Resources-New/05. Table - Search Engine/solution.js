function solve() {
   document.querySelector('#searchBtn').addEventListener('click', onClick);

   function onClick() {
      //   TODO: 
      let textArr = document.querySelectorAll("table tbody tr");
      
         let searcher = document.querySelector("#searchField").value.toLowerCase();
         let matcher = new RegExp(`${searcher}`, "g")
      for (let i = 0; i < textArr.length; i++) {
         textArr[i].classList.remove("select");
      }

        
        
         for (let i = 0; i < textArr.length; i++) {
            console.log(textArr[i]);
            for (let y = 0; y < textArr[i].cells.length; y++) {
               if (textArr[i].cells[y].innerHTML.toLowerCase().match(matcher)){
                  textArr[i].classList.add("select");
               }
            }                        
        }                 
   }
}