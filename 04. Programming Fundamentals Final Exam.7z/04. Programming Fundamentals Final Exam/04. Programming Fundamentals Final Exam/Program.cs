﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace _04._Programming_Fundamentals_Final_Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * https://judge.softuni.bg/Contests/Practice/Index/2303#0
 01. Password Reset

             

            void showPass (string password)
            {
                Console.WriteLine(password);
            }

            string password = Console.ReadLine();
            string [] command = new string [3];
            
            while ((command = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries ))[0] != "Done")
            {
                switch (command[0])
                {
                    case "TakeOdd":
                        string newPass = "";
                        for (int i = 1; i < password.Length; i++)
                        {
                            if (i % 2 == 1)
                            {
                                newPass += password[i];
                            }
                        }
                        password = newPass;
                        showPass(password);
                        break;
                    case "Cut":
                        password= password.Remove(int.Parse(command[1]), int.Parse(command[2]));
                        showPass(password);
                        break;
                    case "Substitute":
                        if (password.Contains(command[1]) == true)
                        {
                           password= password.Replace(command[1], command[2]);
                            showPass(password);
                        }
                        else
                        {
                            Console.WriteLine("Nothing to replace!");
                        }
                       
                        break;
                    default:
                        break;
                }
            }
            Console.WriteLine($"Your password is: {password}");


            02.Fancy Barcodes
           
            int total = int.Parse(Console.ReadLine());
            string pattern = @"@#+[A-Z][a-zA-Z0-9]{4,}[A-Z]@#+";
            for (int i = 0; i < total; i++)
            {
                string input = Console.ReadLine();
                if (Regex.Match(input, pattern).Success)
                {        
                    string patternNumbers = @"[0-9]+";
                    if (Regex.Matches(input, patternNumbers).Count == 0)
                    {
                        Console.WriteLine($"Product group: 00");
                    }
                    else
                    {
                        MatchCollection testMatch = Regex.Matches(input, patternNumbers);
                        Console.WriteLine($"Product group: {string.Join("",testMatch)}");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid barcode");
                }
            }
             
            03.Heroes of Code and Logic VII
            
      


            int total = int.Parse(Console.ReadLine());
             List<Hero> heroes = new List<Hero>();

            for (int i = 0; i < total; i++)
            {
                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

                Hero hero = new Hero();
                hero.name = input[0];
                if (int.Parse(input[1]) < 1 || int.Parse(input[2]) < 0)
                {
                    continue;
                }

                if (int.Parse(input[1]) > 100)
                {
                    hero.hp = 100;
                }
                else
                {
                    hero.hp = int.Parse(input[1]);
                }

                if (int.Parse(input[2]) > 200)
                {
                    hero.mp = 200;
                }
                else
                {
                    hero.mp = int.Parse(input[2]);
                }
                
                heroes.Add(hero);
            }
            string[] command = new string[4];

            while ((command = Console.ReadLine().Split(" - ", StringSplitOptions.RemoveEmptyEntries))[0] != "End")
            {
                Hero hero = heroes.FirstOrDefault(n => n.name == command[1]);

                switch (command[0])
                {
                    case "CastSpell":
                        if (hero.mp > int.Parse(command[2]))
                        {
                            hero.mp -= int.Parse(command[2]);
                            Console.WriteLine($"{hero.name} has successfully cast {command[3]} and now has {hero.mp} MP!");
                        }
                        else
                        {
                            Console.WriteLine($"{hero.name} does not have enough MP to cast {command[3]}!"); 
                        }
                        break;
                    case "TakeDamage":
                        if (hero.hp > int.Parse(command[2]))
                        {    
                            Console.WriteLine($"{hero.name} was hit for {command[2]} HP by {command[3]} and now has {hero.hp - int.Parse(command[2])} HP left!");
                            hero.hp -= int.Parse(command[2]);
                        }
                        else
                        {
                            Console.WriteLine($"{hero.name} has been killed by {command[3]}!");
                            heroes.Remove(hero);
                        }
                        break;
                    case "Recharge":
                        if (hero.mp + int.Parse(command[2]) > 200)
                        {
                            int recovered = int.Parse(command[2]) - (hero.mp + int.Parse(command[2]) )% 200;
                            Console.WriteLine($"{hero.name} recharged for {recovered} MP!");
                            hero.mp = 200;
                        }
                        else
                        {
                            Console.WriteLine($"{hero.name} recharged for {command[2]} MP!");
                            hero.mp += int.Parse(command[2]);
                        }
                        
                        break;
                    case "Heal":
                        if (hero.hp + int.Parse(command[2]) > 100)
                        {
                            int test = (hero.hp + int.Parse(command[2]) ) % 100;
                            int recovered = int.Parse(command[2]) - test;
                            Console.WriteLine($"{hero.name} healed for {recovered} HP!");
                            hero.hp = 100;
                        }
                        else
                        {
                            Console.WriteLine($"{hero.name} healed for {command[2]} HP!");
                            hero.hp += int.Parse(command[2]);
                        }
                        break;

                    default:
                        break;



                }
            }
            heroes= heroes.OrderByDescending(n => n.hp).ThenBy(n => n.name).ToList();
            foreach (var item in heroes)
            {
                Console.WriteLine($"{item.name}\n  HP: {item.hp}\n  MP: {item.mp}");
            }
            */
        }
    }
}
class Hero
{
    public string name  // property
    { get; set; }
    public int hp  // property
    { get; set; }
    public int mp  // property
    { get; set; }
}