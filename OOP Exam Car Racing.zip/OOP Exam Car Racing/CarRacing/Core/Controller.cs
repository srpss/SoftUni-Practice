﻿using CarRacing.Core.Contracts;
using CarRacing.Models;
using CarRacing.Models.Cars;
using CarRacing.Models.Cars.Contracts;
using CarRacing.Models.Maps;
using CarRacing.Models.Racers;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Repositories;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace CarRacing.Core
{
    class Controller : IController
    {
        CarRepository carRepo;
        RacerRepository raceRepo;
        Map map;

        public Controller()
        {
            this.carRepo = new CarRepository();
            this.raceRepo = new RacerRepository();
            this.map = new Map();
        }

        public string AddCar(string type, string make, string model, string VIN, int horsePower)
        {
            ICar car = null;
            if (type == "SuperCar")
            {
                 car = new SuperCar(make, model, VIN, horsePower);
            }
            else if (type == "TunedCar")
            {
                 car = new TunedCar(make, model, VIN, horsePower);
            }
            else
            {
                throw new ArgumentException(ExceptionMessages.InvalidCarType);
            }
            carRepo.Add(car);
            return string.Format
                (OutputMessages.SuccessfullyAddedCar, make, model, VIN);
        }

        public string AddRacer(string type, string username, string carVIN)
        {
            IRacer racer = null;
            ICar car = carRepo.Models.FirstOrDefault(n => n.VIN == carVIN);
            if (car == null)
            {
                throw new ArgumentException(ExceptionMessages.CarCannotBeFound);
            }
            if (type == "ProfessionalRacer")
            {
                racer = new ProfessionalRacer(username, car);
            }
            else if (type == "StreetRacer")
            {
                racer = new StreetRacer(username, car);
            }            
            else
            {
                throw new ArgumentException(ExceptionMessages.InvalidRacerType);
            }
            raceRepo.Add(racer);
            return string.Format(OutputMessages.SuccessfullyAddedRacer, username);
        }

        public string BeginRace(string racerOneUsername, string racerTwoUsername)
        {
            IRacer raceOne = raceRepo.Models.FirstOrDefault(n => n.Username == racerOneUsername);
            IRacer raceTwo = raceRepo.Models.FirstOrDefault(n => n.Username == racerTwoUsername);
            if (raceOne == null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.RacerCannotBeFound, racerOneUsername));
            }
            else if (raceTwo == null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.RacerCannotBeFound, racerTwoUsername));
            }
            return map.StartRace(raceOne, raceTwo);
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var racer in raceRepo.Models.OrderByDescending(n => n.DrivingExperience).ThenBy(n => n.Username))
            {
                string type = "";
                if (racer.RacingBehavior == "aggressive")
                {
                    type = "StreetRacer";
                }
                else if (racer.RacingBehavior == "strict")
                {
                    type = "ProfessionalRacer";
                }
                sb.AppendLine($"{type}: {racer.Username}");
                sb.AppendLine($"--Driving behavior: {racer.RacingBehavior}");
                sb.AppendLine($"--Driving experience: {racer.DrivingExperience}");
                sb.AppendLine($"--Car: {racer.Car.Make} {racer.Car.Model} ({racer.Car.VIN})");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
