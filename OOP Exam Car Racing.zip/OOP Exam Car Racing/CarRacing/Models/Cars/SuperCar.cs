﻿using CarRacing.Models.Cars;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models
{
    class SuperCar : Car
    {
        public SuperCar(string make, string model, string vIN, int horsePower) : base(make, model, vIN, horsePower, 80, 10)
        {
        }
    }
}
