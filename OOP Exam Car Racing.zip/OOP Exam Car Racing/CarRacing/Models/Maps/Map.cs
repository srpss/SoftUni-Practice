﻿using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Maps
{
    class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            if (!racerOne.IsAvailable() && !racerTwo.IsAvailable())
            {
                return (OutputMessages.RaceCannotBeCompleted);
            }
            else if (!racerOne.IsAvailable())
            {
                return (string.Format(OutputMessages.OneRacerIsNotAvailable, racerTwo.Username, racerOne.Username)); 
            }
            else if (!racerTwo.IsAvailable())
            {
                return (string.Format(OutputMessages.OneRacerIsNotAvailable, racerOne.Username, racerTwo.Username));
            }
            else
            {
                racerOne.Race();
                racerTwo.Race();
                decimal winOne = 0;
                decimal winTwo = 0;
                winOne = Calc(racerOne, winOne);
                winTwo = Calc(racerTwo, winTwo);
                if (winOne > winTwo)
                {
                    return (string.Format(OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerOne.Username));
                }
                else
                {
                    return (string.Format(OutputMessages.RacerWinsRace, racerTwo.Username, racerOne.Username, racerTwo.Username));
                }
            }
        }

        private static decimal Calc(IRacer racerOne, decimal winOne)
        {
            if (racerOne.RacingBehavior == "strict")
            {
                winOne = racerOne.Car.HorsePower * racerOne.DrivingExperience * 1.2m;
            }
            else if (racerOne.RacingBehavior == "aggressive")
            {
                winOne = racerOne.Car.HorsePower * racerOne.DrivingExperience * 1.1m;
            }

            return winOne;
        }
    }
}
