﻿using CarRacing.Models.Racers.Contracts;
using CarRacing.Repositories.Contracts;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarRacing.Repositories
{
    class RacerRepository : IRepository<IRacer>
    {
        private readonly List<IRacer> models;
        public IReadOnlyCollection<IRacer> Models => models;
        public RacerRepository()
        {
            models = new List<IRacer>();
        }
        public void Add(IRacer model)
        {
            if (model == null)
            {
                throw new ArgumentException(ExceptionMessages.InvalidAddRacerRepository);
            }
            models.Add(model);
        }
        public bool Remove(IRacer model)
        {
            bool check = false;
            int index = 0;
            foreach (var item in models)
            {
                if (item.Username == model.Username)
                {
                    check = true;
                }
                index++;
            }
            if (check == true)
            {
                models.RemoveAt(index);
                return true;
            }
            return false;
        }
        public IRacer FindBy(string property)
        {
            return models.FirstOrDefault(n => n.Username == property);
        }
       
    }
}
