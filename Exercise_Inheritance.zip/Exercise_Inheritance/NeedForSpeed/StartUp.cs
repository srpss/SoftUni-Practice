﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
             RaceMotorcycle test = new RaceMotorcycle(8, 100);
            test.Drive(2);
        }
    }
}
