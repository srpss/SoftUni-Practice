﻿using Easter.Core.Contracts;
using Easter.Models.Bunnies;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Dyes;
using Easter.Repositories;
using Easter.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Easter.Models.Eggs;
using Easter.Models.Workshops;
using Easter.Models.Eggs.Contracts;

namespace Easter.Core
{
    class Controller : IController
    {
        private int eggsDone;
        private BunnyRepository bunnyRepo;
        private EggRepository eggRepo;
        public Controller()
        {
            bunnyRepo = new BunnyRepository();
            eggRepo = new EggRepository();
        }

        public string AddBunny(string bunnyType, string bunnyName)
        {
            IBunny bunny = null;
            if (bunnyType == "HappyBunny")
            {
                bunny = new HappyBunny(bunnyName);
            }
            else if (bunnyType == "SleepyBunny")
            {
                bunny = new SleepyBunny(bunnyName);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidBunnyType);
            }
            bunnyRepo.Add(bunny);
            return string.Format(OutputMessages.BunnyAdded, bunnyType, bunnyName);
        }

        public string AddDyeToBunny(string bunnyName, int power)
        {
            Dye dye = new Dye(power);
            if (bunnyRepo.FindByName(bunnyName) != null)
            {
                bunnyRepo.Models.FirstOrDefault(n => n.Name == bunnyName).AddDye(dye);
                return string.Format(OutputMessages.DyeAdded, power, bunnyName);
            }
            else
            {
                throw new InvalidOperationException(ExceptionMessages.InexistentBunny);
            }
        }

        public string AddEgg(string eggName, int energyRequired)
        {
            Egg egg = new Egg(eggName, energyRequired);
            eggRepo.Add(egg);
            return string.Format(OutputMessages.EggAdded, eggName);
        }

        public string ColorEgg(string eggName)
        {
            List<IBunny> bunnies = bunnyRepo.Models.Where(n => n.Energy >= 50).ToList();
            List<IBunny> bunniesToRenive = new List<IBunny>();
            if (bunnies.Count == 0)
            {
                throw new InvalidOperationException(ExceptionMessages.BunniesNotReady);
            }
            Workshop workshop = new Workshop();
            IEgg egg = eggRepo.FindByName(eggName);
            foreach (var bunny in bunnies)
            {
                if (egg.EnergyRequired == 0)
                {
                    break;
                }
                workshop.Color(egg, bunny);
                if (bunny.Energy == 0)
                {
                    bunniesToRenive.Add(bunny);
                }
            }
            foreach (var item in bunniesToRenive)
            {
                bunnyRepo.Remove(item);
            }
            if (!egg.IsDone())
            {                
                return string.Format(OutputMessages.EggIsNotDone, eggName);
            }
            else
            {
                eggsDone++;
                return string.Format(OutputMessages.EggIsDone, eggName);
            }
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{eggsDone} eggs are done!");
            sb.AppendLine($"Bunnies info:");
            foreach (var bunny in bunnyRepo.Models)
            {
                sb.AppendLine($"Name: {bunny.Name}"); 
                sb.AppendLine($"Energy: {bunny.Energy}");
                int notfinished = 0;
                foreach (var item in bunny.Dyes)
                {
                    if (!item.IsFinished())
                    {
                        notfinished++;
                    }                
                }
                sb.AppendLine($"Dyes: {notfinished} not finished");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
