﻿using Easter.Models.Bunnies.Contracts;
using Easter.Models.Eggs.Contracts;
using Easter.Models.Workshops.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Easter.Models.Workshops
{
    class Workshop : IWorkshop
    {
        public void Color(IEgg egg, IBunny bunny)
        {
            foreach (var dye in bunny.Dyes)
            {
                while (!dye.IsFinished() || bunny.Energy == 0)
                {
                    dye.Use();
                    bunny.Work();
                    egg.GetColored();
                    if (egg.IsDone())
                    {
                        break;
                    }
                }
                if (egg.IsDone() || bunny.Energy == 0)
                {
                    break;
                }
            }
        }
    }
}
