﻿using Easter.Models.Dyes.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Easter.Models.Dyes
{
    class Dye : IDye
    {
        private int power;
        public int Power
        {
            get => power;
            internal set
            {
                if (value < 0 || power + value < 0)
                {
                    power = 0;
                }
                else
                {
                  power = value;
                }                
            }
        }

        public Dye(int power)
        {
            Power = power;
        }

        public void Use()
        {
            Power -= 10;
        }
        public bool IsFinished()
        {
            if (power == 0)
            {
                return true;
            }
            return false;
        }     
    }
}
