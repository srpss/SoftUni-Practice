﻿namespace Presents.Tests
{
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    public class PresentsTests
    {
        [Test]
        public void PresentCreation()
        {
            Present present = new Present("Present", 1.5);
            Assert.AreEqual("Present", present.Name);
            Assert.AreEqual(1.5, present.Magic);
        }
        [Test]
        public void PresentCreationByUsingPublicSet()
        {
            Present present = new Present("Present", 1.5);
            present.Name = "Present1";
            present.Magic = 2;
            Assert.AreEqual("Present1", present.Name);
            Assert.AreEqual(2, present.Magic);
        }
        [Test]
        public void BagCreation()
        {
            Present present = new Present("Present", 1.5);
            Bag bag = new Bag();
            string test = bag.Create(present);
            Assert.AreEqual($"Successfully added present {present.Name}.", test);
        }
        [Test]
        public void BagCreationNull()
        {
            Present present = null;
            Bag bag = new Bag();                        
            Assert.Throws<ArgumentNullException>(() => bag.Create(present));
        }
        [Test]
        public void BagCreationExistsAlready()
        {
            Present present = new Present("Present", 1.5);
            Bag bag = new Bag();
            bag.Create(present);            
            Assert.Throws<InvalidOperationException>(() => bag.Create(present));
        }
        [Test]
        public void BagRemoveTrue()
        {
            Present present = new Present("Present", 1.5);
            Bag bag = new Bag();
            bag.Create(present);
            bool test = bag.Remove(present);
            Assert.IsTrue(test);
        }
        [Test]
        public void BagRemoveFalse()
        {
            Present present = new Present("Present", 1.5);
            Bag bag = new Bag();           
            bool test = bag.Remove(present);
            Assert.IsFalse(test);
        }
        [Test]
        public void BagLeastMagic()
        {
            Present present = new Present("Present", 1.5);
            Present present1 = new Present("Present1", 1);
            Bag bag = new Bag();
            bag.Create(present);
            bag.Create(present1);
            Present test =bag.GetPresentWithLeastMagic();
            Assert.AreEqual(1, test.Magic);
        }
        [Test]
        public void BagGetPresent()
        {
            Present present = new Present("Present", 1.5);
            Present present1 = new Present("Present1", 1);
            Bag bag = new Bag(); 
            bag.Create(present);
            bag.Create(present1);
            Present test = bag.GetPresent("Present1");
            Assert.AreEqual(1, test.Magic);
        }
        [Test]
        public void BagGetPresents()
        {
            Present present = new Present("Present", 1.5);
            Present present1 = new Present("Present1", 1);
            Bag bag = new Bag();
            bag.Create(present);
            bag.Create(present1);
            IReadOnlyCollection<Present> test = bag.GetPresents();
            Assert.AreEqual(2, test.Count);
        }
    }
}
