﻿namespace Robots.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class RobotsTests
    {
        [Test]
        public void RobotCreate()
        {
            Robot robot = new Robot("Martin", 100);
            Assert.AreEqual("Martin", robot.Name);
            Assert.AreEqual(100, robot.Battery);
            Assert.AreEqual(100, robot.MaximumBattery);
        }
        [Test]
        public void RobotManagerCreate()
        {
            RobotManager robotManager = new RobotManager(2);
            Assert.AreEqual(2, robotManager.Capacity);
        }
        [Test]
        public void RobotManagerNegativeCapacity()
        {
            RobotManager robotManager;
            Assert.Throws< ArgumentException>(() => robotManager = new RobotManager(-1));
        }
        [Test]
        public void RobotManagerCapacity()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            Robot robot1 = new Robot("Martin1", 100);
            robotManager.Add(robot);
            robotManager.Add(robot1);
            Assert.AreEqual(2, robotManager.Count);
        }
        [Test]
        public void RobotManagerAddSameRabot()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);            
            Assert.Throws<InvalidOperationException>(() => robotManager.Add(robot));
        }
        [Test]
        public void RobotManagerAddCapacityError()
        {
            RobotManager robotManager = new RobotManager(1);
            Robot robot = new Robot("Martin", 100);
            Robot robot1 = new Robot("Martin1", 100);
            robotManager.Add(robot);
            Assert.Throws<InvalidOperationException>(() => robotManager.Add(robot1));
        }
        [Test]
        public void RobotManagerRemove()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);
            robotManager.Remove("Martin");
            Assert.AreEqual(0, robotManager.Count);
        }
        [Test]
        public void RobotManagerRemoveNull()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);
            Assert.Throws<InvalidOperationException>(() => robotManager.Remove(null));
        }
        [Test]
        public void RobotManagerWork()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);
            robotManager.Work("Martin", "Test", 100);            
            Assert.Throws<InvalidOperationException>(() => robotManager.Work("Martin", "Test", 100));
        }
        [Test]
        public void RobotManagerWorkDoesNotExist()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);
            Assert.Throws<InvalidOperationException>(() => robotManager.Work("Martin11", "Test", 100));
        }
        [Test]
        public void RobotManagerChargeInvalidName()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);
            robotManager.Charge("Martin");
            Assert.Throws<InvalidOperationException>(() => robotManager.Charge("Martin11"));
        }
        [Test]
        public void RobotManagerCharge()
        {
            RobotManager robotManager = new RobotManager(2);
            Robot robot = new Robot("Martin", 100);
            robotManager.Add(robot);
            robotManager.Charge("Martin");
        }
    }    
}
