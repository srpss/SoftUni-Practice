﻿namespace Robots
{
    class StartUp
    {
        static void Main()
        {
        }
    }
}
